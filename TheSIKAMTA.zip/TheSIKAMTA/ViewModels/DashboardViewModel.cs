namespace SIKAMTA.ViewModels;

public class DashboardViewModel
{
    public decimal TotalMasuk { get; set; }

    public decimal TotalKeluar { get; set; }

    public decimal Saldo { get; set; }

    public List<string> BulanLabels { get; set; } = new();

    public List<decimal> DataMasuk { get; set; } = new();

    public List<decimal> DataKeluar { get; set; } = new();
}