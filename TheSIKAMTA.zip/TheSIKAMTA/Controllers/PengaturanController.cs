using Microsoft.AspNetCore.Mvc;
using SIKAMTA.Data;
using SIKAMTA.Models;

namespace SIKAMTA.Controllers;

public class PengaturanController : Controller
{
    private readonly AppDbContext _context;
    private readonly IWebHostEnvironment _env;
    
    public PengaturanController(
        AppDbContext context,
        IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        var data = _context.Pengaturan.FirstOrDefault();

        if (data == null)
        {
            return Content(
                "Data pengaturan belum tersedia");
        }

        return View(data);
    }

    [HttpPost]
    public IActionResult Index(Pengaturan model)
    {
        var data = _context.Pengaturan.FirstOrDefault();

        if (data == null)
            return NotFound();

        data.NamaMushola = model.NamaMushola;
        data.Alamat = model.Alamat;
        data.KetuaDKM = model.KetuaDKM;
        data.Bendahara = model.Bendahara;
        data.Telepon = model.Telepon;
        data.Email = model.Email;
        if (model.FileLogo != null)
{
    string fileName =
        Guid.NewGuid().ToString()
        + Path.GetExtension(
            model.FileLogo.FileName);

    string uploadFolder =
        Path.Combine(
            _env.WebRootPath,
            "uploads");

    if (!Directory.Exists(uploadFolder))
    {
        Directory.CreateDirectory(uploadFolder);
    }

    string filePath =
        Path.Combine(
            uploadFolder,
            fileName);

    using (var stream =
        new FileStream(
            filePath,
            FileMode.Create))
    {
        model.FileLogo.CopyTo(stream);
    }

    data.Logo = fileName;
}

        _context.SaveChanges();

        TempData["Sukses"] =
            "Pengaturan berhasil disimpan";

        return RedirectToAction(nameof(Index));
    }
}