using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SIKAMTA.Data;
using SIKAMTA.Models;

namespace SIKAMTA.Controllers;

public class TransaksiKasController : Controller
{
    private readonly AppDbContext _context;

    public TransaksiKasController(AppDbContext context)
    {
        _context = context;
    }

    // =========================
    // LIST DATA
    // =========================
    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        var data = _context.TransaksiKas
            .Include(x => x.Kategori)
            .OrderByDescending(x => x.Tanggal)
            .ToList();

        return View(data);
    }

    // =========================
    // CREATE
    // =========================
    [HttpGet]
    public IActionResult Create()
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        ViewBag.Kategori = _context.Kategori
            .OrderBy(x => x.NamaKategori)
            .ToList();

        return View();
    }

    [HttpPost]
    public IActionResult Create(TransaksiKas model)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Kategori = _context.Kategori
                .OrderBy(x => x.NamaKategori)
                .ToList();

            return View(model);
        }

        _context.TransaksiKas.Add(model);
        _context.SaveChanges();

        return RedirectToAction("Index");
    }

    // =========================
    // EDIT
    // =========================
    [HttpGet]
    public IActionResult Edit(int id)
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        var transaksi = _context.TransaksiKas
            .FirstOrDefault(x => x.Id == id);

        if (transaksi == null)
        {
            return NotFound();
        }

        ViewBag.Kategori = _context.Kategori
            .OrderBy(x => x.NamaKategori)
            .ToList();

        return View(transaksi);
    }

    [HttpPost]
    public IActionResult Edit(TransaksiKas model)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Kategori = _context.Kategori
                .OrderBy(x => x.NamaKategori)
                .ToList();

            return View(model);
        }

        _context.TransaksiKas.Update(model);
        _context.SaveChanges();

        return RedirectToAction("Index");
    }

    // =========================
    // DELETE
    // =========================
    [HttpGet]
    public IActionResult Delete(int id)
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        var transaksi = _context.TransaksiKas
            .Include(x => x.Kategori)
            .FirstOrDefault(x => x.Id == id);

        if (transaksi == null)
        {
            return NotFound();
        }

        return View(transaksi);
    }

    [HttpPost]
    public IActionResult DeleteConfirm(int id)
    {
        var transaksi = _context.TransaksiKas
            .FirstOrDefault(x => x.Id == id);

        if (transaksi != null)
        {
            _context.TransaksiKas.Remove(transaksi);
            _context.SaveChanges();
        }

        return RedirectToAction("Index");
    }
}