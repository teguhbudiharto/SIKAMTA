using Microsoft.AspNetCore.Mvc;
using SIKAMTA.Data;

namespace SIKAMTA.Controllers;

public class TestDbController : Controller
{
    private readonly AppDbContext _context;

    public TestDbController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        try
        {
            int jumlahUser = _context.Users.Count();

            return Content(
                $"Koneksi Database Berhasil.\nJumlah User: {jumlahUser}"
            );
        }
        catch (Exception ex)
        {
            return Content(
                $"Koneksi Database Gagal.\n\n{ex.Message}"
            );
        }
    }
}