using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SIKAMTA.Data;
using SIKAMTA.ViewModels;

namespace SIKAMTA.Controllers;

public class KasController : Controller
{
    private readonly AppDbContext _context;

    public KasController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        decimal totalMasuk =
            _context.TransaksiKas
            .Where(x => x.Jenis == "Masuk")
            .Sum(x => x.Nominal);

        decimal totalKeluar =
            _context.TransaksiKas
            .Where(x => x.Jenis == "Keluar")
            .Sum(x => x.Nominal);

        var transaksi =
            _context.TransaksiKas
            .Include(x => x.Kategori)
            .OrderByDescending(x => x.Tanggal)
            .Take(10)
            .ToList();

        var model = new KasPublikViewModel
        {
            TotalMasuk = totalMasuk,
            TotalKeluar = totalKeluar,
            Saldo = totalMasuk - totalKeluar,
            TransaksiTerakhir = transaksi
        };

        return View(model);
    }
}