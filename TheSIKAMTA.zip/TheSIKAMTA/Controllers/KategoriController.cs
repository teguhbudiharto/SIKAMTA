using Microsoft.AspNetCore.Mvc;
using SIKAMTA.Data;
using SIKAMTA.Models;

namespace SIKAMTA.Controllers;

public class KategoriController : Controller
{
    private readonly AppDbContext _context;

    public KategoriController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        var data = _context.Kategori
            .OrderBy(x => x.NamaKategori)
            .ToList();

        return View(data);
    }


[HttpGet]
public IActionResult Create()
{
    if (string.IsNullOrEmpty(
        HttpContext.Session.GetString("Username")))
    {
        return RedirectToAction(
            "Login",
            "Account");
    }

    return View();
}

[HttpPost]
public IActionResult Create(Kategori model)
{
    if (!ModelState.IsValid)
    {
        return View(model);
    }

    _context.Kategori.Add(model);
    _context.SaveChanges();

    return RedirectToAction("Index");
}



[HttpGet]
public IActionResult Edit(int id)
{
    var kategori = _context.Kategori.Find(id);

    if (kategori == null)
    {
        return NotFound();
    }

    return View(kategori);
}

[HttpPost]
public IActionResult Edit(Kategori model)
{
    if (!ModelState.IsValid)
    {
        return View(model);
    }

    _context.Kategori.Update(model);
    _context.SaveChanges();

    return RedirectToAction("Index");
}

[HttpGet]
public IActionResult Delete(int id)
{
    var kategori = _context.Kategori.Find(id);

    if (kategori == null)
    {
        return NotFound();
    }

    return View(kategori);
}

[HttpPost]
public IActionResult DeleteConfirm(int id)
{
    var kategori = _context.Kategori.Find(id);

    if (kategori != null)
    {
        _context.Kategori.Remove(kategori);
        _context.SaveChanges();
    }

    return RedirectToAction("Index");
}
}