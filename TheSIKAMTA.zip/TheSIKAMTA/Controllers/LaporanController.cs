using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SIKAMTA.Data;
using SIKAMTA.Services;
using SIKAMTA.ViewModels;

namespace SIKAMTA.Controllers;

public class LaporanController : Controller
{
    private readonly AppDbContext _context;
    private readonly PdfService _pdfService;

    public LaporanController(
        AppDbContext context,
        PdfService pdfService)
    {
        _context = context;
        _pdfService = pdfService;
    }

    // ==================================
    // LAPORAN BULANAN
    // ==================================
    public IActionResult Index(int? bulan, int? tahun)
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        int bulanFilter = bulan ?? DateTime.Now.Month;
        int tahunFilter = tahun ?? DateTime.Now.Year;

        var data = _context.TransaksiKas
            .Include(x => x.Kategori)
            .Where(x =>
                x.Tanggal.Month == bulanFilter &&
                x.Tanggal.Year == tahunFilter)
            .OrderBy(x => x.Tanggal)
            .ToList();

        decimal totalMasuk = data
            .Where(x => x.Jenis == "Masuk")
            .Sum(x => x.Nominal);

        decimal totalKeluar = data
            .Where(x => x.Jenis == "Keluar")
            .Sum(x => x.Nominal);

        var model = new LaporanViewModel
        {
            Bulan = bulanFilter,
            Tahun = tahunFilter,
            TotalMasuk = totalMasuk,
            TotalKeluar = totalKeluar,
            Saldo = totalMasuk - totalKeluar,
            Data = data
        };

        return View(model);
    }

    // ==================================
    // CETAK PDF
    // ==================================
    public IActionResult Pdf(int bulan, int tahun)
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        var data = _context.TransaksiKas
            .Include(x => x.Kategori)
            .Where(x =>
                x.Tanggal.Month == bulan &&
                x.Tanggal.Year == tahun)
            .OrderBy(x => x.Tanggal)
            .ToList();

        decimal totalMasuk = data
            .Where(x => x.Jenis == "Masuk")
            .Sum(x => x.Nominal);

        decimal totalKeluar = data
            .Where(x => x.Jenis == "Keluar")
            .Sum(x => x.Nominal);

        var model = new LaporanViewModel
        {
            Bulan = bulan,
            Tahun = tahun,
            TotalMasuk = totalMasuk,
            TotalKeluar = totalKeluar,
            Saldo = totalMasuk - totalKeluar,
            Data = data
        };

        var pdfBytes = _pdfService.GenerateLaporan(model);

        return File(
            pdfBytes,
            "application/pdf",
            $"LaporanKas-{bulan}-{tahun}.pdf");
    }
}