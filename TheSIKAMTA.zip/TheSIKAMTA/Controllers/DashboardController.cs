using Microsoft.AspNetCore.Mvc;
using SIKAMTA.Data;
using SIKAMTA.ViewModels;

namespace SIKAMTA.Controllers;

public class DashboardController : Controller
{
    private readonly AppDbContext _context;

    public DashboardController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(
            HttpContext.Session.GetString("Username")))
        {
            return RedirectToAction(
                "Login",
                "Account");
        }

        decimal totalMasuk = _context.TransaksiKas
            .Where(x => x.Jenis == "Masuk")
            .Sum(x => (decimal?)x.Nominal) ?? 0;

        decimal totalKeluar = _context.TransaksiKas
            .Where(x => x.Jenis == "Keluar")
            .Sum(x => (decimal?)x.Nominal) ?? 0;

        var bulanLabels = new List<string>();
        var dataMasuk = new List<decimal>();
        var dataKeluar = new List<decimal>();

        for (int bulan = 1; bulan <= 12; bulan++)
        {
            bulanLabels.Add(GetNamaBulan(bulan));

            decimal masuk = _context.TransaksiKas
                .Where(x =>
                    x.Jenis == "Masuk" &&
                    x.Tanggal.Month == bulan)
                .Sum(x => (decimal?)x.Nominal) ?? 0;

            decimal keluar = _context.TransaksiKas
                .Where(x =>
                    x.Jenis == "Keluar" &&
                    x.Tanggal.Month == bulan)
                .Sum(x => (decimal?)x.Nominal) ?? 0;

            dataMasuk.Add(masuk);
            dataKeluar.Add(keluar);
        }

        DashboardViewModel model =
            new DashboardViewModel
            {
                TotalMasuk = totalMasuk,
                TotalKeluar = totalKeluar,
                Saldo = totalMasuk - totalKeluar,
                BulanLabels = bulanLabels,
                DataMasuk = dataMasuk,
                DataKeluar = dataKeluar
            };

        return View(model);
    }

    private string GetNamaBulan(int bulan)
    {
        string[] namaBulan =
        {
            "",
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "Mei",
            "Jun",
            "Jul",
            "Ags",
            "Sep",
            "Okt",
            "Nov",
            "Des"
        };

        return namaBulan[bulan];
    }
}